package rmi;

public interface TestInterface {
	public long getPID(int v) throws RMIException;
}

package conformance.rmi;

abstract class TestConstants
{
    static final int    PORT = 7000;
}
